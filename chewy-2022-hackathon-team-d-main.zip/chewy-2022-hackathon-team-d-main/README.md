# chewy-2022-hackathon-team-d
Dog Breed Recommender Interface
  * recommends dog breeds according to user preferences such as weight, obedience, etc
